//
//  ShortcutsController.h
//  AppGoX
//
//  Created by 邱宇舟 on 2017/3/10.
//  Copyright © 2017年 appgo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShortcutsController : NSObject

+ (void)bindShortcuts;

@end
