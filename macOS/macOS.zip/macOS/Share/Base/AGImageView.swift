//
//  AGImageView.swift
//  AppGoX
//
//  Created by user on 17.10.30.
//  Copyright © 2017 appgo. All rights reserved.
//

import Cocoa

class AGImageView: NSImageView {
    
    override var mouseDownCanMoveWindow: Bool {
        return true
    }
    
}
