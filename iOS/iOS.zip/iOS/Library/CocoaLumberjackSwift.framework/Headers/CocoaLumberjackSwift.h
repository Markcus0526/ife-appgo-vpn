//
//  CocoaLumberjackSwift.h
//  Lumberjack
//
//  Created by C.W. Betts on 6/25/15.
//
//

//This header is mostly blank because all of the declarations are in Swift.
//Still, this header may still be needed so Swift doesn't complain when importing CocoaLumberjackSwift.

@import CocoaLumberjack;
