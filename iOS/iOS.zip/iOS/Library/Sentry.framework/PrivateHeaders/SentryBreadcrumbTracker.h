//
//  SentryBreadcrumbTracker.h
//  Sentry
//
//  Created by Daniel Griesser on 31/05/2017.
//  Copyright © 2017 Sentry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SentryBreadcrumbTracker : NSObject

- (void)start;

@end
