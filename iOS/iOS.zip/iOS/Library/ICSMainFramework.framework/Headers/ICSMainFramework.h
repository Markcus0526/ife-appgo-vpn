//
//  ICSMainFramework.h
//  ICSMainFramework
//
//  Created by LEI on 3/1/15.
//  Copyright (c) 2015 TouchingApp. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ICSMainFramework.
FOUNDATION_EXPORT double ICSMainFrameworkVersionNumber;

//! Project version string for ICSMainFramework.
FOUNDATION_EXPORT const unsigned char ICSMainFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ICSMainFramework/PublicHeader.h>


#import "OBJCObjectFactory.h"
