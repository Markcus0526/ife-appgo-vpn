//
//  AppDelegate.swift
//  AppGoPro
//
//  Created by LEI on 12/12/15.
//  Copyright © 2015 TouchingApp. All rights reserved.
//

import UIKit
import ICSMainFramework

@UIApplicationMain
private class AppDelegate: ICSMainFramework.AppDelegate {
}

